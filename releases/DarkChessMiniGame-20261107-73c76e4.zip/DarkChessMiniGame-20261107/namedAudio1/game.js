// Named audio assets.
