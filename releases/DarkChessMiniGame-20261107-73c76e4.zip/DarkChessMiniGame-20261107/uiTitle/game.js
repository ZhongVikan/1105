// Shared match-title art.
