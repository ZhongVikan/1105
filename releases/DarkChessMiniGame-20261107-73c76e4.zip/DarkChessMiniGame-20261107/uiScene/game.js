// UI resource subpackage
