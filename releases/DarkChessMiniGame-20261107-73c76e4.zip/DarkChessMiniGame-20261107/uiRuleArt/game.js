// Rule illustration resource package.
