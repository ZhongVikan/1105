// Check-fork announcement assets.
