// UI resource subpackage.
